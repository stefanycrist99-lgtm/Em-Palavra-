function tab(id,btn){
  document.querySelectorAll('.view').forEach(function(v){v.classList.remove('show');});
  var el=document.getElementById(id);
  if(el){el.classList.add('show');}
  document.querySelectorAll('.chip').forEach(function(b){b.classList.remove('active');});
  if(btn){btn.classList.add('active');}
  window.scrollTo(0,0);
}

let current=1,ctab='visao';
function showChapter(n=1){if(!data[n])return;document.querySelectorAll('.view').forEach(e=>e.classList.remove('show'));document.getElementById('capitulo').classList.add('show');current=n;ctab='visao';document.querySelectorAll('.ct').forEach((b,i)=>b.classList.toggle('active',i===0));render();window.scrollTo({top:0,behavior:'smooth'})}
function render(){let d=data[current];document.getElementById('chapterTitle').textContent=d.title;document.getElementById('chapterMeta').textContent=d.meta;document.getElementById('favText').textContent=localStorage.getItem('ep-fav-'+current)?'Salvo ✓':'Salvar estudo';renderTab()}
function chapterTab(t,b){ctab=t;document.querySelectorAll('.ct').forEach(x=>x.classList.remove('active'));b.classList.add('active');renderTab()}
function list(arr){return '<ul>'+arr.map(x=>'<li>'+x+'</li>').join('')+'</ul>'}
function renderTab(){let d=data[current],e=document.getElementById('chapterContent');
if(ctab==='visao')e.innerHTML=`<div class="verse">“${d.verse}”<br><small>${d.ref}</small></div><div class="cols"><div><div class="section"><h3>📖 O que acontece?</h3><p>${d.happens}</p></div><div class="section"><h3>🔎 Detalhes que podem passar despercebidos</h3>${list(d.details.split('\n'))}</div><div class="section"><h3>👥 Personagens</h3><p>${d.characters}</p></div><div class="section"><h3>📍 Lugares</h3><p>${d.places}</p></div></div><div><div class="section"><h3>💡 Interpretação</h3><p>${d.interpretation}</p></div><div class="section"><h3>🔗 Referências cruzadas</h3>${list(d.related)}</div><div class="section"><h3>⚠️ Cuidados na interpretação</h3><p>${d.caution}</p></div></div></div><div class="callout"><b>🌱 Para sempre lembrar</b><p>${d.forever}</p></div>`;
if(ctab==='contexto')e.innerHTML=`<div class="section"><h3>🏺 Contexto histórico e cultural</h3><p>${d.context}</p></div><div class="section"><h3>📖 Contexto literário</h3><p>Leia este capítulo em continuidade com o que veio antes e depois. Observe a situação apresentada pelo próprio livro antes de buscar aplicações posteriores.</p></div><div class="section"><h3>👥 Personagens</h3><p>${d.characters}</p></div><div class="section"><h3>📍 Lugares</h3><p>${d.places}</p></div><div class="callout"><b>Como ler este capítulo</b><p>Pergunte: quem fala? Para quem? Qual é o problema? O que muda? O que se repete? O que o próprio texto explica?</p></div>`;
if(ctab==='interpretacao')e.innerHTML=`<div class="section"><h3>🧠 Sentido central</h3><p>${d.interpretation}</p></div><div class="section"><h3>🔎 Observe antes de concluir</h3><p>${d.observe}</p></div><div class="section"><h3>🔗 Referências cruzadas</h3>${list(d.related)}</div><div class="section"><h3>⚠️ Cuidados na interpretação</h3><p>${d.caution}</p></div><div class="callout"><b>Conexão com o restante da Bíblia</b><p>As referências cruzadas ajudam a comparar temas e desenvolvimentos bíblicos, mas não devem apagar o sentido original do capítulo. Quando uma passagem do Novo Testamento retoma um tema do Antigo, primeiro compreenda o texto antigo e depois observe como o Novo Testamento o utiliza.</p></div>`;
if(ctab==='aplicacao')e.innerHTML=`<div class="callout"><h3>❤️ Aplicação para a vida</h3><p>${d.application}</p></div><div class="section"><h3>🌱 Para sempre lembrar</h3><p>${d.forever}</p></div><div class="section"><h3>📌 Versículo-chave</h3><div class="verse">“${d.verse}”<br><small>${d.ref}</small></div></div><div class="section"><h3>🙏 Oração</h3><p>${d.prayer}</p></div>`;
if(ctab==='reflexao')e.innerHTML=`<div class="callout"><h3>❓ Perguntas para reflexão</h3>${list(d.reflection)}</div><div class="section"><h3>📝 Anotações pessoais</h3><textarea id="notes" placeholder="Escreva o que você percebeu, dúvidas, aplicações e conexões..."></textarea><button onclick="saveNotes()" style="margin-top:8px">Salvar anotação</button><span id="noteStatus" class="saved" style="margin-left:8px"></span></div><div class="section"><h3>🧩 Miniquiz</h3><p class="note">Escolha uma resposta. O resultado fica registrado apenas nesta página.</p>${d.quiz.map((q,i)=>`<div style="margin:18px 0"><p><b>${i+1}. ${q[0]}</b></p><div class="tagrow"><button onclick="quiz(${i},true)">${q[1]}</button><button onclick="quiz(${i},false)">Outra resposta</button></div><div id="quiz-${i}"></div></div>`).join('')}</div>`;loadNotes()}










































studyOrder=Object.keys(data).map(Number);function prevChapter(){let i=studyOrder.indexOf(current);if(i>0)showChapter(studyOrder[i-1])}function nextChapter(){let i=studyOrder.indexOf(current);if(i>=0&&i<studyOrder.length-1)showChapter(studyOrder[i+1])}
function toggleFavorite(){let k='ep-fav-'+current;localStorage.getItem(k)?localStorage.removeItem(k):localStorage.setItem(k,'1');render()}
function saveNotes(){localStorage.setItem('ep-notes-'+current,document.getElementById('notes').value);document.getElementById('noteStatus').textContent='✓ Salvo neste dispositivo'}function loadNotes(){let n=document.getElementById('notes');if(n)n.value=localStorage.getItem('ep-notes-'+current)||''}
function quiz(i,ok){document.getElementById('quiz-'+i).innerHTML=ok?'<div class="callout">✓ Correto! Releia o capítulo e veja por que essa resposta é coerente com o texto.</div>':'<div class="callout">Vale reler o capítulo e tentar novamente.</div>'}
function studyMode(){let b=document.getElementById('studyBox');b.style.display=b.style.display==='none'?'block':'none';b.innerHTML=`<b>📝 Roteiro de estudo — ${data[current].title}</b><ol><li>Leia o capítulo inteiro na sua Bíblia.</li><li>Marque palavras e ideias repetidas.</li><li>Identifique personagens e lugares.</li><li>Escreva em uma frase o problema ou assunto principal.</li><li>Consulte as referências cruzadas.</li><li>Separe claramente o que o texto diz do que você conclui.</li><li>Leia a seção “Cuidados na interpretação”.</li><li>Escreva uma aplicação concreta.</li><li>Ore a partir do capítulo.</li></ol>`}
function randomStudy(){let nums=Object.keys(data).map(Number);showChapter(nums[Math.floor(Math.random()*nums.length)])}
function doSearch(){let q=document.getElementById('q').value.trim().toLowerCase(),r=document.getElementById('results');if(!q){r.innerHTML='<p class="meta">Digite algo para pesquisar.</p>';return}let hits=Object.entries(data).filter(([n,d])=>JSON.stringify(d).toLowerCase().includes(q));r.innerHTML=hits.length?hits.map(([n,d])=>`<div class="result"><strong>${d.title}</strong><br><span>${d.meta}</span><br><button onclick="showChapter(${n})">Abrir estudo</button></div>`).join(''):'<div class="result"><strong>Nenhum resultado nos estudos incluídos.</strong><br><span>Tente “sacrifício”, “sal”, “Moisés”, “presença”, “gratitude”, “Levítico” ou “Egito”.</span></div>'}
function printStudy(){let d=data[current],old=document.body.innerHTML;let content=`<main style="font-family:Georgia,serif;max-width:800px;margin:auto"><h1>${d.title}</h1><p>${d.meta}</p><blockquote>“${d.verse}” — ${d.ref}</blockquote><h2>O que acontece?</h2><p>${d.happens}</p><h2>Contexto</h2><p>${d.context}</p><h2>Detalhes</h2>${list(d.details.split('\n'))}<h2>Interpretação</h2><p>${d.interpretation}</p><h2>Personagens</h2><p>${d.characters}</p><h2>Lugares</h2><p>${d.places}</p><h2>Referências cruzadas</h2>${list(d.related)}<h2>Cuidados na interpretação</h2><p>${d.caution}</p><h2>Aplicação</h2><p>${d.application}</p><h2>Para sempre lembrar</h2><p>${d.forever}</p><h2>Oração</h2><p>${d.prayer}</p><h2>Perguntas para reflexão</h2>${list(d.reflection)}</main>`;document.body.innerHTML=content;window.print();location.reload()}

/* Compatibilidade: garante que a interface continue responsiva mesmo em navegadores
   que lidam de forma inconsistente com atributos onclick em arquivos locais. */
(function(){
  function safeTab(id,btn){
    var el=document.getElementById(id);
    if(!el) return;
    document.querySelectorAll('.view').forEach(function(v){v.classList.remove('show')});
    el.classList.add('show');
    document.querySelectorAll('.chip').forEach(function(b){b.classList.remove('active')});
    if(btn) btn.classList.add('active');
    window.scrollTo(0,0);
  }
  function safeChapter(n){
    n=Number(n);
    if(typeof data==='undefined' || !data[n]) return;
    if(typeof showChapter==='function'){ showChapter(n); return; }
  }
  document.addEventListener('click',function(ev){
    var el=ev.target.closest('[data-action]');
    if(!el) return;
    var a=el.getAttribute('data-action');
    if(a==='tab') safeTab(el.getAttribute('data-target'),el);
    if(a==='chapter') safeChapter(el.getAttribute('data-chapter'));
  });
})();







const books=["Gênesis", "Êxodo", "Levítico", "Números", "Deuteronômio", "Josué", "Juízes", "Rute", "1 Samuel", "2 Samuel", "1 Reis", "2 Reis", "1 Crônicas", "2 Crônicas", "Esdras", "Neemias", "Ester", "Jó", "Salmos", "Provérbios", "Eclesiastes", "Cânticos", "Isaías", "Jeremias", "Lamentações", "Ezequiel", "Daniel", "Oséias", "Joel", "Amós", "Obadias", "Jonas", "Miquéias", "Naum", "Habacuque", "Sofonias", "Ageu", "Zacarias", "Malaquias", "Mateus", "Marcos", "Lucas", "João", "Atos", "Romanos", "1 Coríntios", "2 Coríntios", "Gálatas", "Efésios", "Filipenses", "Colossenses", "1 Tessalonicenses", "2 Tessalonicenses", "1 Timóteo", "2 Timóteo", "Tito", "Filemom", "Hebreus", "Tiago", "1 Pedro", "2 Pedro", "1 João", "2 João", "3 João", "Judas", "Apocalipse"];
document.getElementById('books').innerHTML=books.map(b=>{let fn='showChapter(1)';switch(b){case "Gênesis": fn='showChapter(1)';break;case "Êxodo": fn='showChapter(51)';break;case "Levítico": fn='showChapter(91)';break;case "Números": fn='showChapter(118)';break;case "Deuteronômio": fn='showChapter(154)';break;case "Josué": fn='showChapter(188)';break;case "Juízes": fn='showChapter(212)';break;case "Rute": fn='showChapter(233)';break;case "1 Samuel": fn='showChapter(237)';break;case "2 Samuel": fn='showChapter(268)';break;case "1 Reis": fn='showChapter(292)';break;case "2 Reis": fn='showChapter(314)';break;case "1 Crônicas": fn='showChapter(339)';break;case "2 Crônicas": fn='showChapter(368)';break;case "Esdras": fn='showChapter(404)';break;case "Neemias": fn='showChapter(414)';break;case "Ester": fn='showChapter(427)';break;case "Jó": fn='showChapter(437)';break;case "Salmos": fn='showChapter(479)';break;case "Provérbios": fn='showChapter(629)';break;case "Eclesiastes": fn='showChapter(660)';break;case "Cânticos": fn='showChapter(672)';break;case "Isaías": fn='showChapter(680)';break;case "Jeremias": fn='showChapter(746)';break;case "Lamentações": fn='showChapter(798)';break;case "Ezequiel": fn='showChapter(803)';break;case "Daniel": fn='showChapter(851)';break;case "Oséias": fn='showChapter(863)';break;case "Joel": fn='showChapter(877)';break;case "Amós": fn='showChapter(880)';break;case "Obadias": fn='showChapter(889)';break;case "Jonas": fn='showChapter(890)';break;case "Miquéias": fn='showChapter(894)';break;case "Naum": fn='showChapter(901)';break;case "Habacuque": fn='showChapter(904)';break;case "Sofonias": fn='showChapter(907)';break;case "Ageu": fn='showChapter(910)';break;case "Zacarias": fn='showChapter(912)';break;case "Malaquias": fn='showChapter(926)';break;case "Mateus": fn='showChapter(930)';break;case "Marcos": fn='showChapter(958)';break;case "Lucas": fn='showChapter(974)';break;case "João": fn='showChapter(998)';break;case "Atos": fn='showChapter(1019)';break;case "Romanos": fn='showChapter(1047)';break;case "1 Coríntios": fn='showChapter(1063)';break;case "2 Coríntios": fn='showChapter(1079)';break;case "Gálatas": fn='showChapter(1092)';break;case "Efésios": fn='showChapter(1098)';break;case "Filipenses": fn='showChapter(1104)';break;case "Colossenses": fn='showChapter(1108)';break;case "1 Tessalonicenses": fn='showChapter(1112)';break;case "2 Tessalonicenses": fn='showChapter(1117)';break;case "1 Timóteo": fn='showChapter(1120)';break;case "2 Timóteo": fn='showChapter(1126)';break;case "Tito": fn='showChapter(1130)';break;case "Filemom": fn='showChapter(1133)';break;case "Hebreus": fn='showChapter(1134)';break;case "Tiago": fn='showChapter(1147)';break;case "1 Pedro": fn='showChapter(1152)';break;case "2 Pedro": fn='showChapter(1157)';break;case "1 João": fn='showChapter(1160)';break;case "2 João": fn='showChapter(1165)';break;case "3 João": fn='showChapter(1166)';break;case "Judas": fn='showChapter(1167)';break;case "Apocalipse": fn='showChapter(1168)';break;}return '<div class="card click" onclick="'+fn+'"><div class="icon">📖</div><h3>'+b+'</h3><p>'+b+' 1–'+Object.values(data).filter(x=>x.book===b).length+' disponíveis</p></div>'}).join('');
render();
